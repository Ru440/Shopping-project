document.addEventListener("DOMContentLoaded", function() {
    const products = [
        { id: 1, name: 'Product 1', price: 20.00 },
        { id: 2, name: 'Product 2', price: 30.00 },
        { id: 3, name: 'Product 3', price: 15.00 }
    ];

    const cart = [];

    function renderProducts() {
        const productList = document.getElementById('product-list');
        productList.innerHTML = '';

        products.forEach(product => {
            const button = document.createElement('button');
            button.textContent = 'Add to Cart';
            button.addEventListener('click', () => addToCart(product));

            const productItem = document.createElement('div');
            productItem.innerHTML = `<p>${product.name} - $${product.price.toFixed(2)}</p>`;
            productItem.appendChild(button);

            productList.appendChild(productItem);
        });
    }

    function renderCart() {
        const cartItems = document.getElementById('cart-items');
        const totalPriceElement = document.getElementById('total-price');
        cartItems.innerHTML = '';

        let totalPrice = 0;

        cart.forEach(item => {
            const listItem = document.createElement('li');
            listItem.className = 'cart-item';
            listItem.innerHTML = `<span>${item.name} x${item.quantity}</span> <span>$${(item.price * item.quantity).toFixed(2)}</span>`;

            const removeButton = document.createElement('button');
            removeButton.textContent = 'Remove';
            removeButton.addEventListener('click', () => removeFromCart(item.id));

            listItem.appendChild(removeButton);
            cartItems.appendChild(listItem);

            totalPrice += item.price * item.quantity;
        });

        totalPriceElement.textContent = totalPrice.toFixed(2);
    }

    function addToCart(product) {
        const existingItem = cart.find(item => item.id === product.id);

        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            cart.push({ id: product.id, name: product.name, price: product.price, quantity: 1 });
        }

        renderCart();
    }

    function removeFromCart(productId) {
        const itemIndex = cart.findIndex(item => item.id === productId);

        if (itemIndex !== -1) {
            const item = cart[itemIndex];
            if (item.quantity > 1) {
                item.quantity -= 1;
            } else {
                cart.splice(itemIndex, 1);
            }

            renderCart();
        }
    }

    renderProducts();
    renderCart();
});
