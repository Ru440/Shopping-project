document.addEventListener("DOMContentLoaded", function() {
    showRegistrationForm();

    // Sample registration form HTML
    document.getElementById("registrationForm").innerHTML = `
        <div class="container">
            <h2>User Registration</h2>
            <label for="name">Name:</label>
            <input type="text" id="name" required>
            <label for="email">Email:</label>
            <input type="email" id="email" required>
            <label for="password">Password:</label>
            <input type="password" id="password" required>
            <button onclick="registerUser()">Register</button>
        </div>
    `;

    // Sample login form HTML
    document.getElementById("loginForm").innerHTML = `
        <div class="container">
            <h2>User Login</h2>
            <label for="loginEmail">Email:</label>
            <input type="email" id="loginEmail" required>
            <label for="loginPassword">Password:</label>
            <input type="password" id="loginPassword" required>
            <button onclick="loginUser()">Login</button>
        </div>
    `;

    // Sample shopping cart HTML
    document.getElementById("shoppingCart").innerHTML = `
        <div class="container">
            <h2>Shopping Cart</h2>
            <ul id="cartItems"></ul>
            <p id="totalPrice">Total Price: $0.00</p>
        </div>
    `;

    // Add your JavaScript logic for shopping cart functionality
});

function showRegistrationForm() {
    document.getElementById("registrationForm").classList.remove("hidden");
    document.getElementById("loginForm").classList.add("hidden");
    document.getElementById("shoppingCart").classList.add("hidden");
}

function showLoginForm() {
    document.getElementById("registrationForm").classList.add("hidden");
    document.getElementById("loginForm").classList.remove("hidden");
    document.getElementById("shoppingCart").classList.add("hidden");
}

function showShoppingCart() {
    document.getElementById("registrationForm").classList.add("hidden");
    document.getElementById("loginForm").classList.add("hidden");
    document.getElementById("shoppingCart").classList.remove("hidden");
}

function registerUser() {
    // Implement user registration logic
    // Validate inputs
    // Store user data in local storage or send it to a server

    showLoginForm();
}

function loginUser() {
    const loginEmail = document.getElementById("loginEmail").value;
    const loginPassword = document.getElementById("loginPassword").value;
    const loginError = document.getElementById("loginError");

    // Simple validation - check if email and password are not empty
    if (loginEmail.trim() === "" || loginPassword.trim() === "") {
        loginError.innerText = "Please enter both email and password.";
        return;
    }
    showShoppingCart();
}
